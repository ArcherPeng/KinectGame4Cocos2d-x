//
//  HandData.h
//  KinectGame
//
//  Created by ArcherPeng on 15/3/12.
//
//

#ifndef __KinectGame__HandData__
#define __KinectGame__HandData__

#include <stdio.h>
class HandData
{
public:
    int x=100;
    int y=100;
    int z=100;
};

#endif /* defined(__KinectGame__HandData__) */
