//
//  Config.cpp
//  KinectGame
//
//  Created by ArcherPeng on 15/3/12.
//
//

#include "Config.h"
Config *Config::c = nullptr;