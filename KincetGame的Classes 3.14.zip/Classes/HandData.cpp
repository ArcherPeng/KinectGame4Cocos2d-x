//
//  HandData.cpp
//  KinectGame
//
//  Created by ArcherPeng on 15/3/12.
//
//

#include "HandData.h"
